# Paydirt 2026-10: public download

This archive holds everything needed to check the published numbers for the public cases
and to rerun them.

- bench/            the harness (bench.mjs, lib/, prompts/, harness/, tools/, protocol.json, METHOD.md)
- bench/cases/      the public practice cases: workspace, case.json, truth.json, truth.md
- bench/verify/     the executable proof for each public pair
- bench/commitments.json   one salted SHA-256 per held case (the scored set and the reserve)
- bench/release-notes/     the reasons given for models that were not run, when the release has any
- raw/<model>/<case>.<arm>.<repeat>/   the stored output of every run on a public case:
  events.jsonl (omp's event stream without streaming deltas), request.json (the first
  request exactly as sent: system prompt, tool schemas, task), requests.jsonl (model id,
  reasoning effort and tool list of every request), answer.md, sheet.json, meta.json

The leaderboard is scored on held pairs, so its numbers can be recomputed from the published
per-run outcomes but not from raw output. The practice set is public end to end: for every
model that was also run on it, each outcome can be re-scored from the raw output here.

    node bench/bench.mjs verify --results latest.json --archive paydirt-2026-10-public.tar.gz
    node bench/bench.mjs verify --results practice/latest.json --archive paydirt-2026-10-public.tar.gz

(latest.json, practice/latest.json and the models/ folders next to them are downloaded from the results page.)

Run a model on the practice set yourself:

    node bench/bench.mjs run --set public --models <slug> --run-id mine
    node bench/bench.mjs score --set public --run-id mine
