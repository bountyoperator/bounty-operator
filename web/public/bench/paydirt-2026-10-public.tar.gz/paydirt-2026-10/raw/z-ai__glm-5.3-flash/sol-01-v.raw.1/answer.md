I reviewed both files in the workspace: `src/QuayTools.sol` (TokenOps safe-transfer wrapper and QuayMath full-precision mulDiv) and `src/AsterQuay.sol` (a custody receipt vault with keeper-reported yield, exit fee, deposit cap, pause, and owner/guardian/keeper roles).

## What I verified as sound

- `QuayMath.mulDiv` is a faithful port of the canonical OpenZeppelin/Solmate full-precision algorithm (512-bit product via `mulmod`, borrow-subtracted remainder, power-of-two factoring, Newton-Raphson inverse with the correct six iterations starting from `(3 * d) ^ 2` XOR-magic, `denominator > high` overflow guard, division-by-zero guard). The added `roundUp` flag correctly bumps on non-zero `remainder` with an overflow guard. No fault found.
- `TokenOps._call` correctly rejects codeless targets, failed calls, and non-`true` boolean returns while tolerating empty return data.
- Reentrancy: all entry points that move the asset (`deposit`, `mint`, `withdraw`, `redeem`, `reportYield`, `sweepToken`) share the `entered`-based `nonReentrant` guard; `transfer`/`transferFrom` make no external calls.
- Access control is consistent: `reportYield` keeper-only, admin setters `onlyOwner`, `setPaused` correctly restricts the guardian to pausing only; `sweepToken` protects the vault's own asset and itself, so the owner cannot drain user principal.
- Share/asset conversion consistency: `previewWithdraw`/`previewRedeem` match `withdraw`/`redeem`; the exit-fee-on-gross formula (`bps / (BPS + bps)`, round-up) keeps `fee < gross`, and the fee is always covered by the redeemed shares' backing, so `totalAssets() == 0` with `totalSupply > 0` is not reachable through normal flows.

## Findings

1. **Donation-based share inflation with zero-share deposits (medium).** `totalAssets()` is the raw token balance and `deposit` mints `previewDeposit(assets)` (floor rounding) with no requirement that shares > 0. An attacker can seed 1 share, donate asset directly to the vault (direct transfers bypass `depositCap`), and a sandwiched depositor then receives 0 receipts while their assets stay in the vault; the attacker redeems the inflated share and captures the victim's entire deposit.

2. **Yield-report sandwiching (medium).** `reportYield` atomically raises the share price; deposits have no entry fee, no cooldown, and `exitFeeBps` defaults to 0 (capped at 1%). Anyone can front-run the keeper's report with a deposit and back-run it with a redeem, capturing a pro-rata — with large deposits, nearly all — of the reported yield that was meant for existing holders.

3. **ERC-20 approve race (low).** `approve` overwrites the allowance outright with no reset-to-zero step or permit-style mechanism, so a spender can front-run an allowance change and spend both the old and the new allowance.

No `draft-report.md` exists in the workspace.

```json
{"findings":[{"file":"src/AsterQuay.sol","function":"deposit","line_start":143,"line_end":151,"severity":"medium","claim":"deposit mints floor-rounded previewDeposit(assets) against a raw balanceOf-derived totalAssets() and accepts a zero-share result, with no minimum-supply/virtual-offset defense: an attacker can seed one share, donate asset directly to the vault (bypassing depositCap) to inflate the rate, and a sandwiched depositor receives 0 receipts while forfeiting their entire deposit to the attacker's redemption."},{"file":"src/AsterQuay.sol","function":"reportYield","line_start":215,"line_end":222,"severity":"medium","claim":"Keeper yield reports raise the share price atomically while deposits carry no entry fee or cooldown and the exit fee defaults to 0 (capped at 1%), so an attacker can front-run reportYield with a deposit and back-run it with a redeem, capturing most or all of the reported yield that existing holders were meant to receive."},{"file":"src/AsterQuay.sol","function":"approve","line_start":196,"line_end":200,"severity":"low","claim":"approve overwrites the allowance without the standard approve-race mitigation, so a spender can front-run an allowance change and spend both the previous and the new allowance of receipt tokens."}],"rejected":[],"verdict":"n/a","max_severity":"medium"}
```