I reviewed both files in the workspace: `src/LoomPrimitives.sol` (48 lines) and `src/Cinderloom.sol` (304 lines). Here is my analysis.

## Review

**`src/LoomPrimitives.sol`** — checked and found safe:
- `TokenWire._invoke` (lines 22–34) correctly guards low-level token calls: code-presence check, success check, and strict 32-byte/`==1` return decoding, so non-reverting false-returning tokens are caught.
- `LoomLatch` (lines 37–48) is a sound cross-function reentrancy mutex (`latchState` 1↔2, nested latched calls revert with `LoomBusy`).

**`src/Cinderloom.sol`** — the accounting core (`_inscribe`, `currentEmberIndex`, `embersOf`, `kindle`'s carry-forward of `remaining` + `looseEmbers`) is internally consistent; the `unchecked` subtraction in `loosen` is properly guarded; `recoverForeignThread` blocks both the filament token and the native asset; `totalFilaments`/`account.filaments` invariants hold; `_sendEmbers` reverts on failed delivery so no funds are silently lost.

**The one real flaw is a cross-function reentrancy hole:**

- Every state-changing entry point carries the `latched` modifier — `kindle` (136), `weave` (159), `loosen` (178), `drawEmbers` (195), `recoverForeignThread` (224) — **except `unweave` (line 206)**, which has no guard at all.
- `drawEmbers` pays out *before* zeroing state: line 200 `_sendEmbers(msg.sender, quantity)` runs while line 201 (`weaves[msg.sender].bankedEmbers = 0;`) has not yet executed. In isolation that is survivable because every re-enterable function is latched — but `unweave` bypasses the latch.
- Exploit: a contract user with banked embers `E` and filaments `F` calls `drawEmbers()`; during the native payout in its `receive()`, it re-enters `unweave()`. The re-entrant `_inscribe` (line 207) produces `delta = 0` (the outer call already advanced `emberMark` to `emberIndex`), so the full `bankedEmbers == E` and `filaments == F` are still intact; the inner call pays out `E` a second time plus `F`, all before the outer call zeroes the bank. Net result: the attacker receives `2E + F` instead of `E + F`, with the extra `E` taken from the pooled native fuel that belongs to other stakers and to the remaining burn schedule. (Re-entering `unweave` a second time reverts — both counters are already zero — so the amplification is bounded at 2× per cycle, but it can be repeated each accrual cycle.)

A fix on either side closes it: add `latched` to `unweave`, or zero `bankedEmbers`/`filaments` before the payout in `drawEmbers`. The root cause is the guard omission on `unweave`, since the drawEmbers ordering is safe as long as every entry point is latched.

No `draft-report.md` exists in the workspace, so `rejected` is empty and `verdict` is `n/a`.

```json
{"findings":[{"file":"src/Cinderloom.sol","function":"unweave","line_start":206,"line_end":219,"severity":"high","claim":"unweave is the only state-changing entry point missing the latched reentrancy guard; because drawEmbers sends the native payout before zeroing bankedEmbers (line 200-201), a contract can re-enter unweave during that payout, when its banked embers and filaments are still un-zeroed, and get paid a second time, stealing pooled ember fuel owed to other stakers."}],"rejected":[],"verdict":"n/a","max_severity":"high"}
```