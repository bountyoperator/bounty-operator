I reviewed the two Solidity files in the workspace. Here is my analysis.

## Files reviewed

- `src/TollWeaver.sol` (323 lines) — fee-collection/allocation contract
- `src/libraries/CoinMoves.sol` (44 lines) — minimal ERC-20 call wrapper

## Findings

**Critical — unauthenticated service-beneficiary takeover (`src/TollWeaver.sol:180-185`, `setServiceBeneficiary`)**

Every other administrative setter is gated with `onlySteward` (`setRouteRate` line 156, `setServiceWeight` line 164, `setCourier` line 172, `setContinuityFund` line 188, `setIntakePaused` line 196, `setAssetPolicy` line 202), but `setServiceBeneficiary` at line 180 has **no access-control modifier**. Any caller can:

1. Set `serviceBeneficiary` to an attacker-controlled address (front-running the steward at any time).
2. Call `releaseProceeds(asset)` (line 239, permissionless by design), which pushes `ledger.serviceAccrued` to the attacker-set `beneficiary` (line 250).

This drains the service share of every accrued asset, and the attacker can also permanently misdirect all future service proceeds. This is direct theft of protocol funds, not just griefing.

**Checked and found safe**

- Reentrancy: `nonReentrant` guard (`_entered`, lines 105-110) covers all state-changing entry points including `_receiveCharge`'s `pull`/`push` paths; token-callback reentry is blocked.
- Fee-on-transfer / abnormal tokens: `_receiveCharge`'s before/after balance delta check (lines 315-319) reverts on mismatch, so accruals can't exceed tokens actually received; `CoinMoves._call` fails closed on empty contracts, failed calls, and non-`true` returns, while tolerating empty-return tokens (lines 32-44).
- Limit accounting: `setAssetPolicy` enforces `limit >= accrued` (line 206), so the `outstandingLimit - outstanding` subtraction (line 307) cannot underflow; `returnSurplus` correctly excludes reserved proceeds (line 266).
- Rounding: `quoteRouteCharge` and the service split round down; no over-collection.
- Steward two-step transfer, zero-address checks, and pause semantics behave as documented.

```json
{"findings":[{"file":"src/TollWeaver.sol","function":"setServiceBeneficiary","line_start":180,"line_end":185,"severity":"critical","claim":"setServiceBeneficiary lacks the onlySteward modifier that all other admin setters have, so anyone can redirect the service payout address and then trigger releaseProceeds to steal the accrued service proceeds of every asset (and misdirect all future service funds)."}],"rejected":[],"verdict":"n/a","max_severity":"critical"}
```