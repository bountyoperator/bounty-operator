I reviewed all three source files in `src/` (the workspace contains nothing else — no `draft-report.md`, tests, or config).

## Analysis

**Authorization model.** `authenticate` (tideloom-handlers.ts:22-28) validates the claimed principal against the stored member (existence, tenant match, role match); `manager`/`staff` add role gates. I traced every handler's object access:

- `getBill`, `amendBill`, `issueBill`, `voidBill`, `recordPayment`, `issueCredit`, `getCredit` all resolve objects through tenant-scoped store getters (`getBillForTenant`, `getCreditForTenant`) — safe.
- `createBill` writes into `ctx.principal.tenantId` only — safe.
- `inspectBill` uses the unscoped `store.getBill`, but is gated to `platform` staff, matching the getter's documented purpose — safe.
- `listBills` ignores the `tenantId` query selector for non-platform roles — safe.

**The fault.** `downloadPayment` (tideloom-handlers.ts:195-204) calls `store.getRemittance(id)` — the tenant-**unscoped** getter (tideloom-store.ts:187-189) — after only `authenticate()`. A clerk (read-only role) of marina A can fetch marina B's remittance record by ID. Remittance IDs are sequential (`remit-1`, `remit-2`, … from the shared counter at tideloom-store.ts:60-64), so enumeration is trivial. This leaks cross-tenant financial data: `amountMinor`, `reference` (bank/cash reference), `billId`, `tenantId`. The scoped getter `getRemittanceForTenant` (tideloom-store.ts:181-184) exists and is clearly what this endpoint should use. Rated **high**: cross-tenant read-only disclosure of payment records by any authenticated principal, trivially enumerable, but no write access or auth bypass.

**Checked and found safe (not reported):** production error bodies strip `internalMessage`/`stack`/`cause` (`presentable`, tideloom-http.ts:51-55) and default to production unless `NODE_ENV=development`; `BadInput` never echoes submitted values; money values are bounded safe integers and balance arithmetic can't overflow; pagination is regex-validated and bounded; audit history is capped at 500 with frozen events; `AuditBus.subscribe` intentionally swallows sink failures while the in-process history retains events.

```json
{"findings":[{"file":"src/tideloom-handlers.ts","function":"downloadPayment","line_start":195,"line_end":204,"severity":"high","claim":"downloadPayment authenticates the caller but then reads the remittance via the tenant-unscoped store.getRemittance instead of getRemittanceForTenant, so any authenticated member of any marina (including read-only clerks) can fetch any other marina's remittance receipt by ID; IDs are sequential (remit-1, remit-2, …), making cross-tenant enumeration trivial and exposing amounts and bank/cash payment references to other tenants."}],"rejected":[],"verdict":"n/a","max_severity":"high"}
```