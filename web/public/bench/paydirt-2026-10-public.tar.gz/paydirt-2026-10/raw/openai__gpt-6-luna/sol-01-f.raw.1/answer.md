```json
{"findings":[],"rejected":[],"verdict":"n/a","max_severity":"unrated"}
```