The draft’s unchecked-overflow/drain claim is unsupported. `processOrder` enforces the order ceiling and checks `totalAllocated + order.amount` with checked arithmetic before recovering the authority’s signature and calling `_allocateFunds` (`src/ReelPayoutDesk.sol:143-155`); the issuance limit is also capped (`src/ReelPayoutDesk.sol:117-120`). The PoC instead adds an unrestricted `exposeAllocateFunds` method in a derived harness and calls it directly, bypassing that path (`draft-report.md:103-110,134-145`).

There is a separate high-severity issue: the signed hash omits `creator`, so a mempool observer can redirect a valid signed order to themselves. This supports a high-severity recipient-theft finding, not the draft’s claim of unlimited issuance.

```json
{
  "findings": [
    {
      "file": "src/PayoutOrderLib.sol",
      "function": "hash",
      "line_start": 47,
      "line_end": 49,
      "severity": "high",
      "claim": "The EIP-712 hash omits `order.creator`, so a mempool observer can change a valid signed order's recipient to themselves without invalidating the signature. `processOrder` then credits the attacker and marks the order ID processed, diverting the payout intended for the named creator."
    }
  ],
  "rejected": [
    {
      "quote": "Critical: unchecked arithmetic in `_allocateFunds` lets an attacker credit an unlimited balance and drain the reserve"
    },
    {
      "quote": "The overflow is reachable through the public `processOrder` entry point, because the per-order ceiling and the issuance-limit check are ineffective against the wrap-around."
    },
    {
      "quote": "Once `totalAllocated` has wrapped, the issuance-limit check passes for any amount, so the limit is bypassed for good."
    },
    {
      "quote": "An attacker with no privileges ends up with a desk balance far above anything the authority ever signed and withdraws the entire reserve of the desk with a single `withdraw` call."
    },
    {
      "quote": "Any account can trigger the overflow through the public entry point, and the behaviour shown below was observed on the unmodified contract."
    },
    {
      "quote": "ReelPayoutDeskHarness is a thin wrapper used only to keep the PoC short; no protocol logic is changed."
    },
    {
      "quote": "The attacker is neither the owner nor the authority and does not need a signed payout order."
    }
  ],
  "verdict": "unsupported",
  "max_severity": "unrated"
}
```