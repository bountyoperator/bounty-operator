I've read all four files. Here is my review.

## What the code actually does

`_softClose` (src/QuoinhallSaleroom.sol:171-178) is **not** unbounded:

```solidity
if (lot.closesAt - block.timestamp > SOFT_CLOSE_WINDOW) return;
if (lot.prolongations >= MAX_PROLONGATIONS) return;   // L173
lot.prolongations += 1;                                // L175
lot.closesAt += SOFT_CLOSE_STEP;
```

`MAX_PROLONGATIONS = 9` and `SOFT_CLOSE_STEP = 20 minutes` (L57-58), and `prolongations` is never reset. The close can therefore be pushed out at most 9 × 20 min = **3 hours** past the scheduled close, no matter how many late offers are placed. The draft quotes L172 and L176 of `_softClose` but silently omits the cap on L173/L175, and then asserts "nothing bounds how often this happens" — the opposite of what the code says. The code comment on L169-170 ("capped at MAX_PROLONGATIONS per lot"), the changelog (KV-09 soft-close fix) and the programme's prior-review table all describe this behaviour, so the draft's "oversight, not a design choice" framing is also contradicted. The draft's own PoC only exercises 5 rounds (well under the cap of 9), so its output does not evidence indefinite prolongation; at most it shows a 100-minute delay, and the design ceiling is 3 hours — below the 24-hour Medium threshold and squarely inside the programme's out-of-scope clause for remediation behaviour. The draft's "dust amount (say 1 wei)" premise is also wrong: `minimumOffer` enforces a 2.5% raise (`MIN_RAISE_BPS = 250`).

## The real defect the draft missed

`conclude()` (L196-216) sets `lot.concluded = true` **only** in the unsold branch (L203). In the sold branch (L206-215) the flag is never written, so `if (lot.concluded) revert LotAlreadyConcluded()` (L200) never triggers for a lot that had a leader. `conclude()` is permissionless, so it can be called over and over: each call re-credits `accruedFees += fee` and sends `leadingOffer - fee` to the seller again, out of the contract's single shared ETH pool (other lots' leading offers and outbid bidders' refunds). A seller who bids on their own lot from a second address (KI-1) can drain the pool one `leadingOffer - fee` at a time; even a non-profiting caller can drain it, after which `withdrawRefund()` reverts with `PayoutFailed` and other sellers cannot be paid — theft of escrowed ETH and protocol insolvency (Critical row).

```json
{"findings":[{"file":"src/QuoinhallSaleroom.sol","function":"conclude","line_start":206,"line_end":215,"severity":"critical","claim":"The sold branch of conclude() never sets lot.concluded, so the LotAlreadyConcluded guard never fires and conclude() can be called repeatedly on the same lot; every call pays the seller leadingOffer - fee again out of the contract's single ETH pool (other lots' leading offers and outbid bidders' refunds). A seller bidding on their own lot can drain the escrow, and once drained other sellers cannot be paid and withdrawRefund() reverts, i.e. theft of escrowed ETH and protocol insolvency."}],"rejected":[{"quote":"The soft close mechanism in Quoinhall allows attackers to indefinitely postpone the conclusion of an auction."},{"quote":"The close can be pushed out without limit; every late offer extends `closesAt` again and nothing stops the attacker repeating it for days or weeks."},{"quote":"Both constants are 20 minutes, and nothing bounds how often this happens."},{"quote":"A new offer only has to exceed the leading offer by a dust amount (say 1 wei)"},{"quote":"The code comments, the changelog and the programme page say nothing about a lot being held open this way."},{"quote":"The seller's proceeds and the winner's item are frozen for as long as the attacker likes."},{"quote":"This loop can simply be continued for as long as the attacker desires."},{"quote":"This maps exactly to the High severity row for temporary freezing of ETH or items for more than 7 days."}],"verdict":"unsupported","max_severity":"info"}
```