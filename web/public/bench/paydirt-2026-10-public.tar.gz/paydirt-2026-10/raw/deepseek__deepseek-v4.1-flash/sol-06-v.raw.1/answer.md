I've read both files in the workspace (`src/TollWeaver.sol`, `src/libraries/CoinMoves.sol`) and confirmed there is no `draft-report.md` or any other file. My review:

**Access control sweep of every external entry point:**
- `nominateSteward`, `setRouteRate`, `setServiceWeight`, `setCourier`, `setContinuityFund`, `setIntakePaused`, `setAssetPolicy`, `returnSurplus` — all `onlySteward` ✓
- `acceptStewardship` — checks `msg.sender == pendingSteward` ✓
- `submitSettlementCharge` — `onlyCourier` ✓
- **`setServiceBeneficiary` (line 180) — no `onlySteward`** ✗

**Exploit path:** `setServiceBeneficiary` is callable by anyone. Because `releaseProceeds` (line 239) is intentionally permissionless and pays out to the *current* `serviceBeneficiary`, an attacker can (1) call `setServiceBeneficiary(attacker)`, then (2) call `releaseProceeds(asset)` for any asset, causing every asset's entire `serviceAccrued` bucket — the `serviceBps` share of all collected route/settlement charges — to be transferred to the attacker. This is a direct, immediate theft of funds, and the attacker can also front-run any legitimate release transaction. The other payout destination (`continuityFund`) is still protected by `onlySteward`.

**Things I checked and found sound (not reported):** the `nonReentrant` guard covers all state-mutating fund flows; `_receiveCharge` follows checks-effects-interactions with a balance-delta receipt check; the `outstandingLimit` subtraction is safe because `setAssetPolicy` forbids lowering the limit below accrued amounts; `quoteRouteCharge` is an exact floor-division split (no rounding or overflow bug); `CoinMoves._call` correctly handles both boolean-returning and empty-return ERC-20s and rejects `false`/malformed returns.

```json
{"findings":[{"file":"src/TollWeaver.sol","function":"setServiceBeneficiary","line_start":180,"line_end":185,"severity":"critical","claim":"setServiceBeneficiary is missing the onlySteward modifier, so any account can set the service beneficiary to an arbitrary address; combined with the permissionless releaseProceeds, an attacker can drain every asset's entire accrued service proceeds (the serviceBps share of all collected charges) to themselves at any time."}],"rejected":[],"verdict":"n/a","max_severity":"critical"}
```